import * as Types from './../constants/ActionType';
import * as Message from './../constants/Message';

var initialState = Message.MSG_WELCOME;

const message = (state = initialState, action) => {
    switch (action.type) {
        case Types.CHANGE_MESSAGE:
            return [...state];
        case Types.ADD_TO_CART:
            return Message.MSG_ADD_TO_CART_SUCCESS;
        default:
            return [...state];
    }
}

export default message;